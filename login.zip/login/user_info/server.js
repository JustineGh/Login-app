'use strict';
// ----- initialization
var express = require('express');
var app = express();

app.use(express.static('public'));

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended:false}));

var database = require('./config/database');   // load the database config

var mongoose = require('mongoose'); 
mongoose.connect(database.localUrl);

var Info = require('./models/info');

// ----- Routes
app.get('/',function(req, res){
   res.send('my first node server');
});

app.post('/save_user',function(req, res){
   var response = {
    email:req.body.email,
    name:req.body.name,
    grade:req.body.grade
   }
   res.end(JSON.stringify(response));
   Info.create({
            email:req.body.email,
      name:req.body.name,
      grade:req.body.grade
        }, function (err, todo) {
            if (err)
                res.send(err);
        });
   
});

app.get('/all_info', function(req, res){
   
   Info.find(function(err, infos){
    if(err)
     res.send(err)

    res.json(infos);
   });

// ----- Server
var server = app.listen(3000, function () {
  
  var port = server.address().port

  console.log('Example app listening on port 3000! go to http://localhost:%s',  port)
})