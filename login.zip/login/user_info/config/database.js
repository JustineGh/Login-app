module.exports = {
    remoteUrl : 'mongodb://admin:admin@localhost:27017/userInfo',
    localUrl: 'mongodb://admin:admin@localhost:27017/userInfo'
};